const WORDS = [
    'mesi',
    'neymar',
    'playa',
    'terere',
    'termo',
    'facturas',
    'argentina',
    'musica',
    'futbol',
    'maradona',
    'estanga',
    'pelota',
    'teclado',
    'computadora'
];
